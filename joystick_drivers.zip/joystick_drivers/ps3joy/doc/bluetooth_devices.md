
## Bluetooth Device Compatibility

This driver works with most 2.x Bluetooth adapters.This driver should also work with 3.0 and 4.0 Bluetooth adapters.
Please report other compatible and incompatible Bluetooth adapters through a pull request to this page.

### Adapters that are known to work

* Cambridge Silicon Radio, Ltd Bluetooth Dongle (Bluetooth 4.0) 

### Adapters that are known not to work

* Linksys USBBT100 version 2 (Bluetooth 1.1)
* USB device 0a12:0x0001
