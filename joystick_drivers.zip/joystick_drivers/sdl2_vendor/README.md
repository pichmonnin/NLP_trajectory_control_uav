# sdl2_vendor
Vendor package for providing SDL2 build.
