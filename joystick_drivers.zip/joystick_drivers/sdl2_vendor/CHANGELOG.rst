^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package sdl2_vendor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.3.0 (2023-10-31)
------------------
* Upgrade to SDL2.0.20 (`#270 <https://github.com/ros-drivers/joystick_drivers/issues/270>`_)
* Contributors: Patrick Roncagliolo

3.2.0 (2023-10-10)
------------------

3.1.0 (2022-01-28)
------------------

3.0.1 (2022-01-28)
------------------
* Update SDL2 vendored library to 2.0.14. (`#202 <https://github.com/ros-drivers/joystick_drivers/issues/202>`_)
* Contributors: Chris Lalancette

3.0.0 (2021-03-12)
------------------
* Use INTERFACE_LINK_OPTIONS in sdl2_vendor (`#195 <https://github.com/ros-drivers/joystick_drivers/issues/195>`_)
* Contributors: Scott K Logan

2.4.1 (2020-05-13)
------------------

2.4.0 (2020-05-12)
------------------
* Cross platform joystick support for ROS 2 (`#157 <https://github.com/ros-drivers/joystick_drivers/issues/157>`_)
* Contributors: Chris Lalancette
